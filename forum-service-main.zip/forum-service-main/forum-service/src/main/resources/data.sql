insert into doubts (title, message) values('Dúvida um', 'Erro no código um');
insert into doubts (title, message) values('Dúvida dois', 'Erro no código dois');
insert into doubts (title, message) values('Dúvida três', 'Erro no código três');
insert into doubts (title, message) values('Dúvida quatro', 'Erro no código quatro');
insert into doubts (title, message) values('Dúvida cinco', 'Erro no código cinco');