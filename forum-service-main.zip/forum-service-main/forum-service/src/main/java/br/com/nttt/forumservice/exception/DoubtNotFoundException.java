package br.com.nttt.forumservice.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class DoubtNotFoundException extends RuntimeException {

    public DoubtNotFoundException(Integer id) {
        super(String.format("Doubt not found with ID %s, please enter a valid ID", id));
    }

}
