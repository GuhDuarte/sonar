package br.com.nttt.forumservice.controller.dto;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class MessageResponseDTO {
    private String message;

    public static MessageResponseDTO createMessageResponse(Integer id, String message){

        return MessageResponseDTO.builder().message(message + id).build();
    }

    public static MessageResponseDTO createMessageResponse(String name, String message){

        return MessageResponseDTO.builder().message(message + name).build();
    }
}
