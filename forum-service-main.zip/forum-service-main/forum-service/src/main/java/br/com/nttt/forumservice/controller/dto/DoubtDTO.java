package br.com.nttt.forumservice.controller.dto;

import br.com.nttt.forumservice.repository.model.Doubt;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DoubtDTO {
    public DoubtDTO(Doubt doubt) {
        this.title = doubt.getTitle();
        this.message = doubt.getMessage();
        this.id = doubt.getId();
    }

    private Integer id;

    private String title;

    private String message;

}
