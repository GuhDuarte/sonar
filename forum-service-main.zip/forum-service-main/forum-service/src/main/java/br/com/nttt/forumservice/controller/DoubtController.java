package br.com.nttt.forumservice.controller;

import br.com.nttt.forumservice.controller.dto.DoubtDTO;
import br.com.nttt.forumservice.controller.dto.MessageResponseDTO;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface DoubtController {

    ResponseEntity<List<DoubtDTO>> listAll();

    ResponseEntity<DoubtDTO> listById(Integer id);

    ResponseEntity<MessageResponseDTO> create(DoubtDTO doubtDTO);

    ResponseEntity<MessageResponseDTO> deleteById(Integer id);

}
