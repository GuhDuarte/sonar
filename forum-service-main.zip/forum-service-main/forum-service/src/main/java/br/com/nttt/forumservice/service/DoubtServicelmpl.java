package br.com.nttt.forumservice.service;

import br.com.nttt.forumservice.controller.dto.MessageResponseDTO;
import br.com.nttt.forumservice.controller.dto.DoubtDTO;
import br.com.nttt.forumservice.exception.DoubtNotFoundException;
import br.com.nttt.forumservice.repository.DoubtRepository;
import br.com.nttt.forumservice.repository.model.Doubt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class DoubtServicelmpl implements DoubtService {

    @Autowired
    private DoubtRepository doubtRepository;

    @Override
    public List<DoubtDTO> listAll() {
        List<Doubt> allDoubts = doubtRepository.findAll();
        return allDoubts.stream()
                .map(DoubtDTO::new)
                .collect(Collectors.toList());
    }

    @Override
    public DoubtDTO listById(Integer id) {
        Doubt doubt = verifyIfExistsId(id);

        return convertToDTO(doubt);
    }

    @Override
    public MessageResponseDTO createDoubt(DoubtDTO doubtDTO) {
        Doubt doubt = convertToModel(doubtDTO);
        doubtRepository.save(doubt);

        return MessageResponseDTO.createMessageResponse(doubt.getId(), "Create doubt with ID ");
    }

    @Override
    public MessageResponseDTO deleteById(Integer id) {
        verifyIfExistsId(id);
        doubtRepository.deleteById(id);
        return MessageResponseDTO.createMessageResponse(id,"Deleted doubt with ID ");
    }

    public Doubt verifyIfExistsId(Integer id) {
        return doubtRepository.findById(id).orElseThrow(() -> new DoubtNotFoundException(id));
    }

    public Doubt convertToModel(DoubtDTO doubtDTO) {
        return Doubt.builder()
                .title(doubtDTO.getTitle())
                .message(doubtDTO.getMessage())
                .build();
    }

    public DoubtDTO convertToDTO(Doubt doubt) {
        return DoubtDTO.builder()
                .title(doubt.getTitle())
                .message(doubt.getMessage())
                .build();
    }

}
