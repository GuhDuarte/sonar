package br.com.nttt.forumservice;

//import br.com.nttt.forumservice.config.SpringBootUtil;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ForumServiceApplication {

	public static void main(String[] args) {
		//SpringBootUtil.setRandomPort(8100, 8199);
		SpringApplication.run(ForumServiceApplication.class, args);
	}

}
