package br.com.nttt.forumservice.service;

import br.com.nttt.forumservice.controller.dto.MessageResponseDTO;
import br.com.nttt.forumservice.controller.dto.DoubtDTO;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface DoubtService {

   List<DoubtDTO> listAll();

   MessageResponseDTO createDoubt(DoubtDTO DoubtDTO);

   DoubtDTO listById(Integer id);

    MessageResponseDTO deleteById(Integer id);

}
