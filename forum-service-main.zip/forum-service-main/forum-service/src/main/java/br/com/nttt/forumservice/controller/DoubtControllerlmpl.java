package br.com.nttt.forumservice.controller;

import br.com.nttt.forumservice.controller.dto.DoubtDTO;
import br.com.nttt.forumservice.controller.dto.MessageResponseDTO;
import br.com.nttt.forumservice.service.DoubtService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/doubts")
public class DoubtControllerlmpl implements DoubtController {

    private static Logger logger = LoggerFactory.getLogger(DoubtControllerlmpl.class);

    @Autowired
    private DoubtService doubtService;

    @Override
    @GetMapping("/all")
    public ResponseEntity<List<DoubtDTO>> listAll() {
        logger.info("Listando todas as dúvidas");
        return ResponseEntity.ok(doubtService.listAll());
    }

    @Override
    @GetMapping("/id/{id}")
    public ResponseEntity<DoubtDTO> listById(@PathVariable Integer id) {
        logger.info("Listando dúvida por ID");
        return ResponseEntity.ok(doubtService.listById(id));
    }

    @Override
    @PostMapping("/create")
    public ResponseEntity<MessageResponseDTO> create(@RequestBody DoubtDTO doubtDTO){
        logger.info("Criando uma nova dúvida");
        return ResponseEntity.status(HttpStatus.CREATED).body(doubtService.createDoubt(doubtDTO));
    }

    @Override
    @DeleteMapping("/id/{id}")
    public ResponseEntity<MessageResponseDTO> deleteById(@PathVariable Integer id) {
        logger.info("Excluindo uma dúvida");
        return ResponseEntity.ok(doubtService.deleteById(id));
    }


}
