package br.com.nttt.forumservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForumServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
