package br.com.nttt.forumservice.controller;

import br.com.nttt.forumservice.builder.DoubtDTOBuilder;
import br.com.nttt.forumservice.controller.dto.DoubtDTO;
import br.com.nttt.forumservice.controller.dto.MessageResponseDTO;
import br.com.nttt.forumservice.exception.DoubtNotFoundException;
import br.com.nttt.forumservice.service.DoubtServicelmpl;
import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.util.Collections;

import static br.com.nttt.forumservice.utils.JsonConvertionUtils.asJsonString;
import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
public class DoubtControllerImplTest {

    @Autowired
    private MockMvc mockMvc;

    @Mock
    private DoubtServicelmpl doubtService;

    @InjectMocks
    private DoubtControllerlmpl doubtController;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void returnStatus200WhenListingAll() throws Exception {

        DoubtDTO doubtDTO = DoubtDTOBuilder.builder().build().toDoubtDTO();

        when(doubtService.listAll()).thenReturn(Collections.singletonList(doubtDTO));

        mockMvc.perform(MockMvcRequestBuilders
                        .get("/doubts/all")
                        .contentType(MediaType.APPLICATION_JSON))
                        .andExpect(MockMvcResultMatchers.status().is(200));
    }

    @Test
    public void returnStatus200WhenListById() throws Exception {

        DoubtDTO doubtDTO = DoubtDTOBuilder.builder().build().toDoubtDTO();

        when(doubtService.listById(4)).thenReturn(doubtDTO);

        mockMvc.perform(MockMvcRequestBuilders
                        .get("/doubts/id/4")
                        .contentType(MediaType.APPLICATION_JSON))
                        .andExpect(MockMvcResultMatchers.status().is(200));
    }

    @Test
    public void returnStatus404WhenListByInvalidId() throws Exception {

        when(doubtService.listById(1000000)).thenThrow(DoubtNotFoundException.class);

        mockMvc.perform(MockMvcRequestBuilders
                        .get("/doubts/id/1000000")
                        .contentType(MediaType.APPLICATION_JSON))
                        .andExpect(MockMvcResultMatchers.status().is(404));
    }

    @Test
    public void returnStatus201WhenCreatingDoubt() throws Exception {

        DoubtDTO doubtDTO = DoubtDTOBuilder.builder().build().toDoubtDTO();

        MessageResponseDTO messageResponseDTO = MessageResponseDTO.builder().build();

        when(doubtService.createDoubt(doubtDTO)).thenReturn(messageResponseDTO);

        mockMvc.perform(MockMvcRequestBuilders
                        .post("/doubts/create")
                        .content(asJsonString(doubtDTO))
                        .contentType(MediaType.APPLICATION_JSON))
                        .andExpect(MockMvcResultMatchers.status().is(201));
    }


    @Test
    public void returnStatus200WhenDeleteById() throws Exception {

        MessageResponseDTO messageResponseDTO = MessageResponseDTO.builder().build();

        when(doubtService.deleteById(1)).thenReturn(messageResponseDTO);

        mockMvc.perform(MockMvcRequestBuilders
                        .delete("/doubts/id/1")
                        .contentType(MediaType.APPLICATION_JSON))
                        .andExpect(MockMvcResultMatchers.status().is(200));
    }

    @Test
    public void returnStatus404WhenDeleteByInvalidId() throws Exception {

        when(doubtService.deleteById(1000000)).thenThrow(DoubtNotFoundException.class);

        mockMvc.perform(MockMvcRequestBuilders
                        .delete("/doubts/id/1000000")
                        .contentType(MediaType.APPLICATION_JSON))
                        .andExpect(MockMvcResultMatchers.status().is(404));
    }

}
