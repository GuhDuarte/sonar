package br.com.nttt.forumservice.builder;

import br.com.nttt.forumservice.controller.dto.DoubtDTO;
import lombok.Builder;

@Builder
public class DoubtDTOBuilder {

    @Builder.Default
    private String title = "Dúvida um";

    @Builder.Default
    private String message = "Erro no código um";

    @Builder.Default
    private Integer id = 1;

    public DoubtDTO toDoubtDTO() {
        return new DoubtDTO(id, title, message);
    }

}
