package br.com.nttt.forumservice.builder;

import lombok.Builder;

@Builder
public class MessageResponseDTOBuilder {

    @Builder.Default
    private String message = "Resource created or deleted successfully";

}
