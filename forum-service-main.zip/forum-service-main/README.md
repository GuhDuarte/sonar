# Microsserviço forum-service 

Repositório criado para hospedar o código fonte do microsserviço forum-service, responsável por servir o cadastro e recuperação de dados de dúvidas fictícias. O microsserviço forum-service faz parte da solução utilizada como aplicação teste para a infra do Studios SRE (ver também: [student-service](https://umane.everis.com/git/STUDIOSRE/student-service), [teacher-service](https://umane.everis.com/git/STUDIOSRE/teacher-service), [api-gateway](https://umane.everis.com/git/STUDIOSRE/api-gateway), [discovery-server](https://umane.everis.com/git/STUDIOSRE/discovery-server)). 

# Tecnologias utilizadas: 

* Java 11: linguagem de programação escolhida.
* Maven: gerenciador de dependencias e construtor da aplicação.
* Lombok: biblioteca Java para redução de código boilerplate (código repetitivo. Ex: getters e setters). 
* Spring Boot: framework para facilitar a criação e configuração inicial da aplicação. 
* Spring Web MVC: framework que auxilia no desenvolvimento de aplicações web.
* Spring Data JPA: framework para facilitar o trabalho de persistência de dados. 
* Spring Cloud: framework para facilitar a criação de aplicações distribuídas e escaláveis.

# Organização do projeto:

## Branchs:

* **dev-cluster**: aplicação instrumentada para subir no cluster, via Helm.

* **dev**: aplicação instrumentada para subir via docker-compose.

* **main**: cópia da dev-cluster.

## Pacotes e Classes:

* **config**: contém a classe SpringBootUtil, responsável por subir a aplicação em porta aleatória.

* **controller**: contém a classe DoubtControllerImpl que implementa a interface DoubtController, responsável por recepcionar as requisições web.  

* **dto**: subpacote de controller, contém a classe DoubtDTO e MessageResponseDTO, responsáveis por representar os objetos para transferencia de dados.  

* **exception**: contém as classes DoubtNotFoundException e ExceptionResponse, responsáveis por representar as exceções de recursos não encontrados. 

* **handler**: subpacote de exception, contém a classe CustomizedResponseEntityExceptionHandler, responsável por tratar e lançar as exceções. 

* **repository**: contém a interface DoubtRepository que extende JpaRepository, responsável por abstrair a complexidade de consulta ao banco de dados. 

* **model**: subpacote de repository, contém a classe Doubt, responsável por representar a entidade do banco de dados.

* **resources**: contém o application.properties, arquivo responsável pelas configurações da aplicação.

# Instruções para rodar local, via IDE:

**Pré-requisitos:** Maven, Java 11, IDE de preferência e Docker. 

Clonar o código da branch **dev** e realizar os passos abaixo:

1. Criar uma network, utilizando o seguinte comando:

```
docker network create --driver bridge postgres-network
```

2. Subir container do Postgres, utilizando o seguinte comando:

```
docker run --name meu-postgres --network=postgres-network -e "POSTGRES_PASSWORD=1234!" -p 5432:5432 -d postgres
```

3. Subir container do pgAdmin, utilizando o seguinte comando:

```
docker run --name meu-pgadmin --network=postgres-network -p 15432:80 -e "PGADMIN_DEFAULT_EMAIL=studio@gmail.com" -e "PGADMIN_DEFAULT_PASSWORD=1234!" -d dpage/pgadmin4
```

4. Logar no pgAdmin, acessando localhost:15432 e inserindo os dados: 

* e-mail: studio@gmail.com 

* senha: 1234!  

5. Dentro do pgAdmin, conectar com o banco e inserir os dados disponíveis no arquivo [data.sql](https://umane.everis.com/git/STUDIOSRE/forum-service/-/blob/dev/forum-service/src/main/resources/data.sql)

6. **No application.properties**, alterar as seguintes linhas:

De: spring.datasource.url= jdbc:postgresql://meu-postgres:5432/postgres

Para: spring.datasource.url= jdbc:postgresql://localhost:5432/postgres

Comentar com # as seguintes linhas:

eureka.client.serviceUrl.defaultZone = http://discovery-server:8761/eureka

eureka.instance.prefer-ip-adress=true

7. **No pom.xml**, comentar a seguinte dependencia:

spring-cloud-starter-netflix-eureka-client

Obs: verificar nos logs a porta aleatória que a aplicação subiu. 

# Endpoints:

## GET

* /doubts/all - Retorna todas as dúvidas

* /doubts/id/{id} - Retorna dúvida por id

## POST

* /doubts/create - Cria nova dúvida

Payload: 

```json
{
    "title": " ",
    "message": " "
}
```

## DELETE

* /doubts/id/{id} - Deleta dúvida por id

